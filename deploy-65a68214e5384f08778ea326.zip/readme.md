# City Weather
The GetWeather website is an interactive and user-friendly web application designed to provide real-time weather information to users around the world.
# Farhan Ahmad